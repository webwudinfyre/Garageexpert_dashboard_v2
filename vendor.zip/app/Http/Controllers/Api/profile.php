<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class profile extends Controller
{
    public function passwordchange_api145(Request $request, $id)
    {
print_r('jdjjd');die();
        // $userId = $id;
        // return response()->json('hai');
        // $responseData = User::find($userId);
        // return response()->json(['data' => $responseData]);
    }
}
