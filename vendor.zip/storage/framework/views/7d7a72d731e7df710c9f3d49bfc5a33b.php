    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link " href="/client/dashboard">
                    <i class="bi bi-grid"></i>
                    <span>Client Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->

            

            <li class="nav-item <?php echo e(Request::is('client/office/*') ? 'active' : ''); ?>">
                <a class="nav-link collapsed"
                    href="<?php echo e(route('client.client.office_list', ['id' => encrypt(Auth::user()->id)])); ?>">
                    <i class="bi bi-person"></i>
                    <span>Office List</span>
                </a>
            </li>


            


            <li class="nav-item <?php echo e(Request::is('client/client/Review/*') ? 'active' : ''); ?>">
                <a class="nav-link collapsed"
                    href="<?php echo e(route('client.client.client_review', ['id' => Auth::user()->id])); ?>">
                    <i class="bi bi-layout-text-window-reverse"></i>
                    <span>Review</span>
                </a>
            </li>


            <li class="nav-heading">Pages</li>

            
            <li class="nav-item">
                <a class="nav-link collapsed"
                    href="<?php echo e(route('client.registration.clientdprofilemain', ['id' => encrypt(Auth::user()->id)])); ?>">
                    <i class="bi bi-person"></i>
                    <span>Profile</span>
                </a>
            </li><!-- End Profile Page Nav -->

            

        </ul>

    </aside><!-- End Sidebar-->
<?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/client/layouts/sidebar.blade.php ENDPATH**/ ?>