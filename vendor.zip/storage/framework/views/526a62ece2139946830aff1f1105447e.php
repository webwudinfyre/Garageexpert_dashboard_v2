<?php $__env->startSection('contents'); ?>
    <style>
        .start_date {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
    </style>

    <section class="pagetitle_sec">
        <div id="pagetitle" class="pagetitle">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-12  align-items-center ">
                    <h1>Job List</h1>
                    <nav>
                        <ol class="breadcrumb ">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>

                            <?php if(!empty($search_page)): ?>
                            <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.joballocation.job_list')); ?>">Job List</a></li>
                            <li class="breadcrumb-item active">Job Serach Result</li>
                            <?php elseif(!empty($task_id)): ?>
                            <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.joballocation.job_list')); ?>">
                                    Job
                                    List</a></li>

                            <li class="breadcrumb-item active">
                                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item_list->id == $task_id): ?>
                                        <?php echo e($item_list->task_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>

                            <?php else: ?>
                            <li class="breadcrumb-item active">Job List</li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                </div>

            </div>

        </div>
    </section>


    <?php echo $__env->make('components.task_status_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <section class="section pt-3" id="section_Search">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body ">
                        <div class="row gy-3 mt-3">

                            <form action="<?php echo e(route('admin.joballocation.search')); ?>" class="row g-3" method="GET">

                            <div class="col-xxl-3 col-md-6 ">



                                <div class="row">
                                    <div class="start_date">
                                        <div class="col-sm-4 mt-2">
                                            <label for="inputDate" class="form-label">Start Date :</label>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="date" class="form-control" name="Start_date"  autocomplete="Start_date" value="<?php echo e(!empty($search_page) ? $search_page['start_date'] : ''); ?>">
                                        </div>

                                    </div>
                                    <?php $__errorArgs = ['Start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                            </div>
                            <div class="col-xxl-3 col-md-6">
                                <div class="row">
                                    <div class="start_date">
                                        <div class="col-sm-4  mt-2">
                                            <label for="inputDate" class="form-label">End Date :</label>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="date" class="form-control" name="End_date" autocomplete="End_date" value="<?php echo e(!empty($search_page) ? $search_page['end_date'] : ''); ?>">
                                        </div>

                                    </div>
                                    <?php $__errorArgs = ['End_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-xxl-3 col-md-6 text-center">
                                <div class="row">

                                    <div class="col-sm-12">
                                        <select class="form-select" aria-label="Default select example" name="Task_value">
                                            <option value=""  selected >Please Choose Task</option>

                                            <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?> " <?php echo e(!empty($search_page) && $search_page['Task_value'] == $item->id ? 'selected' : ''); ?>> <span class="service_option_size">
                                                        <?php echo e($item->task_name); ?> </span></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="col-xxl-3 col-md-6 text-center ">
                                <div class="search">
                                    <div class="form-floating mb-3 ">
                                        <button type="submit" class="btn bg-primary_expert"
                                            style="height: 100%; width:50%">search</button>
                                    </div>
                                </div>

                            </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="section pt-3" id="section_admin">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">

                        <div class="card_head">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="col-12">
                                    <h5 class="card-title">Job List</h5>
                                </div>

                            </div>
                        </div>

                        <!-- Table with stripped rows -->
                        <div class="table-responsive">
                            <table id="admin_table" class="table datatable table-striped">
                                <thead>
                                    <tr>
                                        <th>sl.no</th>
                                        <th> Product Code</th>
                                        <th>Office Name</th>
                                        <th>Loaction</th>
                                        <th>Service</th>
                                        <th>Task</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $prdt_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prdt_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($prdt_task->product_add->product_code); ?></td>
                                            <td><?php echo e($prdt_task->product_add->client_pdt->office); ?></td>
                                            <td><?php echo e($prdt_task->product_add->client_pdt->location); ?></td>
                                            <td><?php echo e($prdt_task->type_service->service_name); ?></td>
                                            <td><?php echo e($prdt_task->task->task_name); ?></td>

                                            <td>
                                                <div class="action_icon ">
                                                    <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="View"
                                                        href="<?php echo e(route('admin.joballocation.job_list_view', ['id' => encrypt($prdt_task->product_id)])); ?>">
                                                        <button type="button" class="btn">
                                                            <i class="bi bi-eye"></i>
                                                        </button>
                                                    </a>
                                                    <?php if(!empty($task_id) && $prdt_task->task_id == '3'): ?>
                                                    <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Quotation">

                                                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#Quotation_aproval"
                                                        data-bs-whatever=<?php echo e($prdt_task->id); ?>>
                                                        <i class="bi bi-arrow-right"></i>
                                                    </button>
                                                    </a>

                                                    <?php endif; ?>

                                                </div>


                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </section>
    <section id='assign'>
        <div class="modal fade" id="Quotation_aproval" tabindex="-1" aria-labelledby="Quotation_aproval" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Quotation Aproval</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body mb-5">

                        <div class="row">
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Client Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Office Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Office_Name_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Location Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Location_Name_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Email</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Email_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Phone Number</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Phone_Number_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Product Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Code</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Code_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Brand Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Brand_Name_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Model</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Model_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Name_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                        </div>
                        <form action="<?php echo e(route('admin.joballocation.Quotation_aproval')); ?>" method="GET">
                            <div id="assign_to" class="row">
                                <div class="mb-3">

                                    <input type="hidden" class="form-control" name="pdt_id_name_assign"
                                        id="pdt_id_name_assign">
                                </div>
                                <div class="mb-3">

                                    <input type="hidden" class="form-control" id="user_id" name="user_id"
                                        value="<?php echo e(Auth::user()->id); ?>">
                                </div>


                                <div class="col-md-12 "
                                    style="
                                display: flex;
                                align-content: center;
                                justify-content: space-around;
                            ">
                                    <div class="Confirm_assign d-flex "
                                        style="justify-content: space-around; align-items:center">
                                        <button type="submit" class="btn bg-primary_expert ">Confirm To Quotation </button>
                                    </div>
                                </div>



                            </div>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/admin/joballocation/joblist.blade.php ENDPATH**/ ?>