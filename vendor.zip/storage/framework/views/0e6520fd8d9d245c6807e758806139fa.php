<?php $__env->startSection('contents'); ?>
    <style>
        #timeline-3 {
            height: 400px !important;

        }

        .timeline_links {}

        .active>.page-link,
        .page-link.active {
            z-index: 1;
            color: #dee2e6;
            background-color: #ff530a;
            border-color: #dee2e6;
        }

        .timeline_links.d-flex {
            display: flex;
            justify-content: flex-end;
        }

        .page-link {
            position: relative;
            display: block;

            color: #ff530a;
        }

        .page-link:hover {
            z-index: 2;
            color: #ff530a;
            background-color: var(--bs-pagination-hover-bg);
            border-color: var(--bs-pagination-hover-border-color);
        }
    </style>

    <section class="pagetitle_sec">
        <div id="pagetitle" class="pagetitle">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-8  align-items-center ">
                    <h1>Tracking Details </h1>
                    <nav>
                        <ol class="breadcrumb ">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('client.dashboard.index')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Tracking
                                Details</li>
                        </ol>
                    </nav>
                </div>

                <div class="col-4 d-flex justify-content-end">


                </div>

            </div>

        </div>
    </section>

    <section class="section pt-3" id="section_admin">
        <div class="row">

            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tracking <span>| List</span></h5>

                        <div id="timeline-container" class="timeline-container">
                            <div id="timeline" class="timeline">
                                <div class="row">
                                    <?php $__currentLoopData = $taskHistoryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskId => $taskHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-6 mb-4">
                                            <div class="">
                                                <div class="card-body">
                                                    <div class="timeline_card_head">
                                                        <h4 class="card-title">Code : <?php echo e($taskHistory['product_add_code']); ?>

                                                        </h4>

                                                        <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                            data-bs-title="View"
                                                            href="<?php echo e(route('client.joballocation.job_list_view', ['id' => encrypt($taskHistory['product_add'])])); ?>">

                                                            <i class="bi bi-eye"></i>

                                                        </a>
                                                    </div>



                                                    <ul id="timeline-3" class="timeline-3">
                                                        <li>

                                                            <p>Service: <?php echo e($taskHistory['service_name']); ?></p>
                                                            <p>Brand: <?php echo e($taskHistory['Brand']); ?></p>
                                                            <p>Model: <?php echo e($taskHistory['Model']); ?></p>
                                                            <p>Name: <?php echo e($taskHistory['Item_naame']); ?></p>
                                                            <p>Status: <?php echo e($taskHistory['Status']); ?></p>


                                                        </li>
                                                        <?php $__currentLoopData = $taskHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(is_array($value) && $key !== 'product_add' && $key !== 'product_add_code' && $key !== 'service_name'): ?>
                                                                <li>
                                                                    <?php
                                                                        $subValueParts = explode(
                                                                            '_next_',
                                                                            $value['name'],
                                                                        );
                                                                        $lastPart = end($subValueParts);
                                                                    ?>
                                                                    <div class="timeline-date">
                                                                        <div class="timeline_head">
                                                                            <?php echo e(ucfirst(str_replace('_', ' ', $lastPart))); ?>

                                                                        </div>
                                                                        <div class="timeline_head">
                                                                            <?php echo e($value['Date_Of_Schedule']); ?></div>
                                                                    </div>


                                                                    <div class="timeline-content">




                                                                        <p>Task Status:
                                                                            <?php echo e($value['task_name_status'] === 'New Task' ? 'Progress' : $value['task_name_status']); ?>

                                                                        </p>

                                                                        <p>Assigned : <?php echo e($value['assign_name']); ?></p>

                                                                        <p>Date Of Schedule:
                                                                            <?php echo e($value['Date_Of_Schedule']); ?></p>

                                                                        <?php if(isset($value['quotationValue_value_data'])): ?>
                                                                            <p>Quotation Status:
                                                                                <?php echo e($value['quotationValue_value_data']); ?>

                                                                            </p>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="timeline_links d-flex">
                                <?php echo $client_latest->links(); ?>

                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/client/other/timeline.blade.php ENDPATH**/ ?>