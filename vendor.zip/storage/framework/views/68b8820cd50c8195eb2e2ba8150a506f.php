<?php $__env->startSection('contents'); ?>
<div class="pagetitle">
    <h1>Tech Dashboard</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="row">
<div class="col-12">
    <?php if (isset($component)) { $__componentOriginal2d2c16bd9e1389955f41f715931904e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d2c16bd9e1389955f41f715931904e9 = $attributes; } ?>
<?php $component = App\View\Components\ExampleComponent::resolve(['adminId' => ''.e(Auth::user()->id).'','admin' => 'tech'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('example-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ExampleComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d2c16bd9e1389955f41f715931904e9)): ?>
<?php $attributes = $__attributesOriginal2d2c16bd9e1389955f41f715931904e9; ?>
<?php unset($__attributesOriginal2d2c16bd9e1389955f41f715931904e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d2c16bd9e1389955f41f715931904e9)): ?>
<?php $component = $__componentOriginal2d2c16bd9e1389955f41f715931904e9; ?>
<?php unset($__componentOriginal2d2c16bd9e1389955f41f715931904e9); ?>
<?php endif; ?>
</div>
        <!-- Left side columns -->
        <div class="col-lg-8">
            <div class="row">

                <!-- Sales Card -->


              <!-- Reports -->
              <div class="col-12">
                <div class="card">

                    <div class="card-body">
                        <h5 class="card-title">Calender <span></span></h5>

                        <div id="calendar"></div>

                        <div class="icon_cal mb-1">
                            <i class="bi bi-circle-fill activity-badge orange align-self-start"> New Task </i>
                            <i class="bi bi-circle-fill activity-badge text-primary align-self-start"> Pending </i>
                            <i class="bi bi-circle-fill activity-badge text-success align-self-start"> Completed </i>
                            <i class="bi bi-circle-fill activity-badge text-danger align-self-start"> Quotation </i>
                        </div>




                    </div>

                </div>
            </div><!-- End Reports -->


            </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

            <!-- Recent Activity -->
            <div class="card">


                <div class="card-body">
                    <h5 class="card-title">Recent Task <span> | Latest</span></h5>

                    <div class="activity">


                        <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="activity-item d-flex">
                                <div class="activite-label"> <?php echo e($task_view->updated_at->format('Y-m-d')); ?>


                                    <br><?php echo e($task_view->updated_at->format('H:i:s')); ?>

                                </div>
                                <i
                                    class="bi bi-circle-fill activity-badge <?php echo e($task_view->color_class); ?> align-self-start"></i>
                                <div class="activity-content">
                                    <?php echo e($task_view->product_add->product_code); ?>

                                    <br><?php echo $task_view->Type_service->service_name; ?>

                                    <br><?php echo $task_view->task->task_name; ?>

                                    <br><?php echo $task_view->product_add->client_pdt->office; ?>

                                    <br><?php echo $task_view->product_add->client_pdt->location; ?>



                                </div>
                            </div><!-- End activity item-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>
            </div><!-- End Recent Activity -->




        </div><!-- End Right side columns -->

    </div>
</section>
<section class="view" id="view">
    <div class="modal fade" id="view_equip_1" tabindex="-1" aria-labelledby="view_equip_1" aria-hidden="true">
        <div class="modal-dialog modal-lg  modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Task details</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    
                    
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->startPush('scripts'); ?>

<script src="https://unpkg.com/fullcalendar@5.10.1/main.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            events: '/tasks_1',


            dateClick: function(info) {
                // Example: Fetch additional details using AJAX
                $.ajax({
                    url: '/get_event_details_1', // Your backend endpoint
                    method: 'get',
                    data: {
                        date: info.dateStr // Send the clicked date to the server
                    },
                    success: function(response) {
                        console.log(response);
                        var modalBodyContent =
                            '<table class="table table-responsive"><thead><tr><th>Product Code</th><th>Serial Number</th><th>Description</th><th>Status</th></tr></thead><tbody>';
                        response.forEach(function(item) {
                            modalBodyContent += '<tr><td>' + item.product_add
                                .product_code + '</td><td>' + item.product_add
                                .serial_number + '</td><td><ul><li>' +
                                'Brand :' + item.product_add.equip_pdt.Brand +
                                '</li><li>' + 'Model :' + item.product_add
                                .equip_pdt.Model + '</li><li>' + 'name :' + item
                                .product_add.equip_pdt.Item_name +
                                '</li></ul></td><td>' + item.task.task_name +
                                '</td></tr>';

                        });
                        $('#view_equip_1 .modal-body').html(modalBodyContent);
                        $('#view_equip_1').modal('show');
                    },
                    error: function(error) {
                        console.error('Error fetching event details:', error);
                    }
                });
            }

            // dateClick: function(info) {
            //     // Example: Show a modal with the clicked date

            //     $('#view_equip_1').modal('show');



            // }

        });

        calendar.render();
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('tech.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/tech/dashboard/index.blade.php ENDPATH**/ ?>