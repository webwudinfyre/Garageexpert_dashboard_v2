<div>



    <section class="section dashboard">

        <div class="row">

            <div class="col-xxl-3 col-md-6">
                <div class="card info-card sales-card text-center">



                    <div class="card-body ">
                        <a href="<?php echo e(route('admin.joballocation.job_list_each_task', ['id' => $data_id1['New Task']])); ?>">
                            <h5 class="card-title">New Task </h5>

                            <div class=" d-flex text-center align-items-center justify-content-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <img class="icons_svg" src="<?php echo e(asset('admin/assets/img/New_task.svg')); ?>" >
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($taskCount['New Task']); ?></h6>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div class="card info-card sales-card text-center">



                    <div class="card-body ">
                        <a href="<?php echo e(route('admin.joballocation.job_list_each_task', ['id' => $data_id1['Pending']])); ?>">
                            <h5 class="card-title">Pending Task</h5>

                            <div class=" d-flex text-center align-items-center justify-content-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <img class="icons_svg" src="<?php echo e(asset('admin/assets/img/Pending_task.svg')); ?>" >
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($taskCount['Pending']); ?></h6>


                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div class="card info-card sales-card text-center">



                    <div class="card-body ">
                        <a
                            href="<?php echo e(route('admin.joballocation.job_list_each_task', ['id' => $data_id1['Completed']])); ?>">
                            <h5 class="card-title">Completed Task</h5>

                            <div class=" d-flex text-center align-items-center justify-content-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">

                                 <img class="icons_svg" src="<?php echo e(asset('admin/assets/img/Completed_task.svg')); ?>" >
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($taskCount['Completed']); ?></h6>


                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div class="card info-card sales-card text-center">



                    <div class="card-body ">
                        <a
                            href="<?php echo e(route('admin.joballocation.job_list_each_task', ['id' => $data_id1['Quotation']])); ?>">
                            <h5 class="card-title">Quotation</h5>

                            <div class=" d-flex text-center align-items-center justify-content-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <img class="icons_svg" src="<?php echo e(asset('admin/assets/img/Asign to other.svg')); ?>" >
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($taskCount['Quotation']); ?></h6>


                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </div>

    </section>
</div>
<?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/components/task_status_admin.blade.php ENDPATH**/ ?>