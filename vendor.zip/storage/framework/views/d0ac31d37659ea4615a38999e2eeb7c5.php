<?php $__env->startSection('contents'); ?>
    <section class="pagetitle_sec">
        <div id="pagetitle" class="pagetitle">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-8  align-items-center ">
                    <h1>Technician Reports</h1>
                    <nav>
                        <ol class="breadcrumb ">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Technician Reports</li>

                        </ol>
                    </nav>
                </div>



            </div>

        </div>
    </section>

    <?php
    $asd = $techusers['user_id'];
?>

<?php if (isset($component)) { $__componentOriginal2d2c16bd9e1389955f41f715931904e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d2c16bd9e1389955f41f715931904e9 = $attributes; } ?>
<?php $component = App\View\Components\ExampleComponent::resolve(['adminId' => $asd,'admin' => 'admin'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('example-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ExampleComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d2c16bd9e1389955f41f715931904e9)): ?>
<?php $attributes = $__attributesOriginal2d2c16bd9e1389955f41f715931904e9; ?>
<?php unset($__attributesOriginal2d2c16bd9e1389955f41f715931904e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d2c16bd9e1389955f41f715931904e9)): ?>
<?php $component = $__componentOriginal2d2c16bd9e1389955f41f715931904e9; ?>
<?php unset($__componentOriginal2d2c16bd9e1389955f41f715931904e9); ?>
<?php endif; ?>
    <section class="section pt-3" id="section_admin">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">

                        <div class="card_head">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="col-12">
                                    <h5 class="card-title">Technician Name : <?php echo e($techusers['firstname']); ?>

                                        <?php echo e($techusers['lastname']); ?></h5>
                                </div>

                            </div>
                        </div>


                        <!-- Table with stripped rows -->
                        <div class="table-responsive">
                            <table id="admin_table" class="table datatable table-striped">
                                <thead>
                                    <tr>
                                        <th>Sl.no</th>
                                        <th>
                                            Product Details
                                        </th>
                                        <th>Client Details</th>
                                        <th>Task Status</th>
                                        <th>Type Service</th>
                                        <th>Date</th>


                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $prdt_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prdt_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td>
                                                <ul>
                                                    <li>Product code : <?php echo e($prdt_task->product_add->product_code); ?>

                                                    </li>
                                                    <li>Serial Number:<?php echo e($prdt_task->product_add->serial_number); ?>

                                                    </li>

                                                </ul>

                                            </td>
                                            <td>
                                                <ul>
                                                    <li>Office Name : <?php echo e($prdt_task->product_add->client_pdt->office); ?>

                                                    </li>
                                                    <li>Location :<?php echo e($prdt_task->product_add->client_pdt->location); ?>

                                                    </li>

                                                </ul>

                                            </td>
                                            <td><?php echo e($prdt_task->task->task_name); ?>

                                            </td>
                                            <td><?php echo e($prdt_task->type_service->service_name); ?>

                                            </td>
                                            <?php
                                                $startDate = \Carbon\Carbon::parse($prdt_task->date_of_schedule);
                                                $endDate = \Carbon\Carbon::parse($prdt_task->updated_at);
                                                $dateDifference = $endDate->diffInDays($startDate);

                                                if ($dateDifference === 0) {
                                                    $differenceDescription = 'on date';
                                                } elseif ($dateDifference > 0) {
                                                    $differenceDescription = 'late by ' . $dateDifference . ' days';
                                                } else {
                                                    $differenceDescription =
                                                        'early by ' . abs($dateDifference) . ' days';
                                                }
                                            ?>
                                            <td>
                                                <ul>
                                                    <li>Date Difference: <?php echo e($dateDifference); ?>

                                                    </li>
                                                    <li>Description: <?php echo e($differenceDescription); ?>

                                                    </li>

                                                </ul>

                                            </td>

                                            <td>

                                                <div class="action_icon ">
                                                    <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="View"
                                                        href="<?php echo e(route('admin.joballocation.job_list_view', ['id' => encrypt($prdt_task->product_id)])); ?>">
                                                        <button type="button" class="btn">
                                                            <i class="bi bi-eye"></i>
                                                        </button>
                                                    </a>



                                                </div>

                                            </td>




                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/admin/reports/report_tech_view.blade.php ENDPATH**/ ?>