<?php $__env->startSection('contents'); ?>
    <style>
        .card-title {
            padding: 20px 0 15px 0;
            font-size: 18px;
            font-weight: 500;
            color: #000000;
            font-family: "Poppins", sans-serif;
        }
    </style>
    <div class="pagetitle">
        <h1>Client Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">
            <div class="col-12">

                <?php if (isset($component)) { $__componentOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076 = $attributes; } ?>
<?php $component = App\View\Components\TaskListclient::resolve(['adminId' => ''.e(Auth::user()->id).'','admin' => 'tech'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('task-listclient'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TaskListclient::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076)): ?>
<?php $attributes = $__attributesOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076; ?>
<?php unset($__attributesOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076)): ?>
<?php $component = $__componentOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076; ?>
<?php unset($__componentOriginalde7fb8f70e6f9d2dd2d64f3c6a4c7076); ?>
<?php endif; ?>

            </div>






            <!-- Left side columns -->
            <div class="col-lg-8">
                <div class="row">



                    <!-- Reports -->
                    <div class="col-12">
                        <div class="card">

                            <div class="filter">

                                <a class="icon" href="<?php echo e(route('client.client.tracking_details')); ?>">View More</a>

                            </div>

                            <div class="card-body">
                                <h5 class="card-title">Tracking <span>/Latest</span></h5>

                                <div id="timeline-container" class="timeline-container">
                                    <div id="timeline" class="timeline">
                                        <div class="row">
                                            <?php $__currentLoopData = $taskHistoryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskId => $taskHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-6 col-md-6 mb-4">
                                                    <div class="">
                                                        <div class="card-body">
                                                            <div class="timeline_card_head">
                                                                <h4 class="card-title">Code :
                                                                    <?php echo e($taskHistory['product_add_code']); ?> </h4>

                                                                <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                                    data-bs-title="View"
                                                                    href="<?php echo e(route('client.joballocation.job_list_view', ['id' => encrypt($taskHistory['product_add'])])); ?>">

                                                                    <i class="bi bi-eye"></i>

                                                                </a>
                                                            </div>

                                                            <ul id="timeline-3" class="timeline-3">
                                                                <li>

                                                                    <p>Service: <?php echo e($taskHistory['service_name']); ?></p>
                                                                    <p>Brand: <?php echo e($taskHistory['Brand']); ?></p>
                                                                    <p>Model: <?php echo e($taskHistory['Model']); ?></p>
                                                                    <p>Name: <?php echo e($taskHistory['Item_naame']); ?></p>
                                                                    <p>Status: <?php echo e($taskHistory['Status']); ?></p>

                                                                </li>
                                                                <?php $__currentLoopData = $taskHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(is_array($value) && $key !== 'product_add' && $key !== 'product_add_code' && $key !== 'service_name'): ?>
                                                                        <li>
                                                                            <?php
                                                                                $subValueParts = explode(
                                                                                    '_next_',
                                                                                    $value['name'],
                                                                                );
                                                                                $lastPart = end($subValueParts);
                                                                            ?>
                                                                            <div class="timeline-date">
                                                                                <div class="timeline_head">
                                                                                    <?php echo e(ucfirst(str_replace('_', ' ', $lastPart))); ?>

                                                                                </div>
                                                                                <div class="timeline_head">
                                                                                    <?php echo e($value['Date_Of_Schedule']); ?></div>
                                                                            </div>


                                                                            <div class="timeline-content">


                                                                                <p>Task Status:
                                                                                    <?php echo e($value['task_name_status'] === 'New Task' ? 'Progress' : $value['task_name_status']); ?>

                                                                                </p>

                                                                                <p>Assigned : <?php echo e($value['assign_name']); ?>

                                                                                </p>

                                                                                <p>Date Of Schedule:
                                                                                    <?php echo e($value['Date_Of_Schedule']); ?></p>

                                                                                <?php if(isset($value['quotationValue_value_data'])): ?>
                                                                                    <p>Quotation Status:
                                                                                        <?php echo e($value['quotationValue_value_data']); ?>

                                                                                    </p>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>

                                    
                                </div>


                            </div>

                        </div>
                    </div><!-- End Reports -->


                </div>
            </div><!-- End Left side columns -->

            <!-- Right side columns -->
            <div class="col-lg-4">



                <div class="card" style="height: 475px; overflow-y: auto; scrollbar-width: 1px;">


                    <div class="card-body">
                        <h5 class="card-title">Product Review <span>| Latest</span></h5>


                        <div class="activity">



                            <?php $__currentLoopData = $customer_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="activity-item d-flex">
                                    <div class="activite-label"> <?php echo e($review1->updated_at->format('H:i:s')); ?>

                                    </div>
                                    <i
                                        class="bi bi-circle-fill activity-badge <?php echo e($review1->color_class); ?> align-self-start"></i>
                                    <div class="activity-content">
                                        <?php for($i = 1; $i <= $review1->Product_reviews_star; $i++): ?>
                                            
                                            <label class="star-rating-complete" title="text"><i
                                                    class="bi bi-star-fill"></i> </label>
                                        <?php endfor; ?>
                                        <br><?php echo $review1->Type_service->service_name; ?>

                                        <br><?php echo $review1->product_task_rew->product_add->client_pdt->office; ?>

                                        


                                        

                                    </div>
                                </div><!-- End activity item-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>


               
                <!-- Website Traffic -->

                <!-- News & Updates Traffic -->

            </div><!-- End Right side columns -->

        </div>
    </section>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/client/dashboard/index.blade.php ENDPATH**/ ?>