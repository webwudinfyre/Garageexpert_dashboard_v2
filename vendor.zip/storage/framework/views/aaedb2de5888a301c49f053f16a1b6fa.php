<div class="modal-dialog modal-lg  modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h1 class="modal-title fs-5" id="view">View User</h1>
            <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
        </div>
        <div class="modal-body">
            
            <form action="<?php echo e(route('admin.registration.admincreate')); ?>" class="row g-3" method="POST">
                <?php echo csrf_field(); ?>


                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingfirstName" placeholder="First Name"
                            name="First_Name" required autocomplete="First_Name" autofocus value=<?php echo e($posts->firstname); ?>

                            disabled>
                        <label for="floatingfirstName">First Name</label>
                        <?php $__errorArgs = ['First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert-color" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingLastName" placeholder="Last Name"
                            name="Last_Name" required autocomplete="Last_Name" autofocus disabled
                            value=<?php echo e($posts->firstname); ?>>
                        <label for="floatingLastName"> Last Name</label>
                        <?php $__errorArgs = ['Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert-color" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="email" class="form-control" id="floatingEmail" name="Email" placeholder="Email"
                            required autocomplete="Email" autofocus disabled value=<?php echo e($posts->users->email); ?>>
                        <label for="floatingEmail"> Email</label>
                        <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert-color" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="password" class="form-control" id="floatingPassword" name="Password"
                            placeholder="Password" disabled>
                        <label for="floatingPassword">Password</label>

                        <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert-color" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="col-md-12">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingPhone" name="Phone_number"
                                placeholder="Phone Number" required disabled autocomplete="Phone_number" autofocus
                                value=<?php echo e($posts->phonenumber); ?>>
                            <label for="floatingPhone"> Phone Number</label>
                            <?php $__errorArgs = ['Phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert-color" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <select class="form-select" id="floatingStatus" aria-label="Status" disabled>

                            <option value="1" selected><?php echo e($posts->users->status == '1' ? 'Active' : 'Inactive'); ?>

                            </option>

                        </select>
                        <label for="floatingStatus">Status</label>
                    </div>
                </div>

                <div class="text-center">

                    <button type="button" class="btn bg-primary_expert btn-style"
                        data-bs-dismiss="modal">Close</button>

                </div>
            </form>
        </div>

    </div>
</div>
<?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/admin/registration/admin_view.blade.php ENDPATH**/ ?>