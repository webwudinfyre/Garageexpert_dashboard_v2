<div>
    <!-- The best way to take care of the future is to take care of the present moment. - Thich Nhat Hanh -->
</div><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/components/task-list.blade.php ENDPATH**/ ?>