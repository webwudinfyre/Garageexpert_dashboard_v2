<?php $__env->startSection('contents'); ?>

<div id="pagetitle" class="pagetitle">
    <div class="row d-flex justify-content-between align-items-center">
        <div class="col-8  align-items-center ">
            <h1>Profile</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Technicians Profile</li>
                </ol>
            </nav>
        </div>

    </div>

</div>

<section id="profile">
    <div class="row">
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="edit-profile">
                        <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit">

                        </a>
                    </div>
                    <?php if($Adminusers->avatar): ?>
                        <img src="<?php echo e(asset('storage/images/images/' . $Adminusers->avatar)); ?>" alt="avatar"
                            class="rounded-circle img-fluid" style="width: 150px;">
                    <?php else: ?>
                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp"
                            alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                    <?php endif; ?>


                    <h5 class="my-3"><?php echo (!empty($Adminusers->users->name) ? $Adminusers->users->name : '<span class="placeholder-text">Please Enter ' .  'Name' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></h5>
                    <p class="text-muted mb-1"><?php echo (!empty($Adminusers->Position) ? $Adminusers->Position : '<span class="placeholder-text">Please Enter ' .  'Position' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                    <p class="text-muted mb-4"><?php echo (!empty($Adminusers->Address) ? $Adminusers->Address : '<span class="placeholder-text">Please Enter ' .  'Address' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                    <div class="d-flex justify-content-center mb-2">

                        <button type="button" class="btn bg-primary_expert ms-1">Message</button>
                    </div>
                </div>
            </div>
            <div class="card mb-4 mb-lg-0">
                <div class="card-body ">
                    <div class="head-profie">
                        <h5 class="card-title">Social Media links</h5>
                        <div class="edit-profile">
                            <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit">
                                <button type="button" class="btn" data-bs-toggle="modal"
                                    data-bs-target="#edit_social_Media">
                                    <i class="bi bi-pencil-square"></i>
                                </button></a>
                        </div>
                    </div>

                    <ul class="list-group list-group-flush rounded-3">
                        <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                            <i class="bi bi-linkedin bi-lg text-warning"><span class="icon-name">Linkedin</span></i>
                            <p class="mb-0"><?php echo (!empty($Adminusers->linkedin) ? $Adminusers->linkedin : '<span class="placeholder-text">Please Enter ' .  'linkedin ' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </li>

                        <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                            <i class="bi bi-twitter-x bi-lg"><span class="icon-name">X</span></i>
                            <p class="mb-0"><?php echo (!empty($Adminusers->instagram) ? $Adminusers->instagram : '<span class="placeholder-text">Please Enter ' .  'Instagram' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                            <i class="bi bi-instagram bi-lg"><span class="icon-name">Instagram </span></i>
                            <p class="mb-0"><?php echo (!empty($Adminusers->twitter) ? $Adminusers->twitter : '<span class="placeholder-text">Please Enter ' .  'X' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </li>

                        <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                            <i class="bi bi-facebook bi-lg"><span class="icon-name">Facebook</span></i>
                            <p class="mb-0"><?php echo (!empty($Adminusers->facebook) ? $Adminusers->facebook : '<span class="placeholder-text">Please Enter ' .  'Facebook' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="head-profie">
                        <h5 class="card-title">Basic Details</h5>
                        <div class="edit-profile">
                            <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit">
                                <button type="button" class="btn" data-bs-toggle="modal"
                                    data-bs-target="#Basic_details"><i class="bi bi-pencil-square"></i>
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0">Full Name</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0"><?php echo (!empty($Adminusers->firstname) ? $Adminusers->firstname : '<span class="placeholder-text">Please Enter ' .  'First Name' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?> <?php echo (!empty($Adminusers->lastname) ? $Adminusers->lastname : '<span class="placeholder-text">Please Enter ' .  'Last Name' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0">Postion</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0"><?php echo (!empty($Adminusers->Position) ? $Adminusers->Position : '<span class="placeholder-text">Please Enter ' .  'Position' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0">Email</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0"><?php echo (!empty($Adminusers->users->email) ? $Adminusers->users->email : '<span class="placeholder-text">Please Enter ' .  'Email' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0">Phone</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0"><?php echo (!empty($Adminusers->phonenumber) ? $Adminusers->phonenumber : '<span class="placeholder-text">Please Enter ' .  'Phone' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </div>
                    </div>

                    <hr>
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0">Address</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0"><?php echo (!empty($Adminusers->Address) ? $Adminusers->Address : '<span class="placeholder-text">Please Enter ' .  'Address' . ' <i class="bi bi-exclamation-circle"></i></span>'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    
                </div>

            </div>
        </div>
    </div>

    <section class="edit_social">
        <div class="modal fade" id="edit_social_Media" tabindex="-1" aria-labelledby="edit_social_Media"
            aria-hidden="true">
            <div class="modal-dialog modal-lg  modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Social Media links</h1>
                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close"><i
                                class="bi bi-x"></i></button>
                    </div>
                    <div class="modal-body">
                        <form
                            action="<?php echo e(route('admin.registration.tech.profilecreatesocial', ['id' => encrypt($Adminusers->id)])); ?>"
                            class="row g-3" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatinglinkedin"
                                        placeholder="linkedin " name="linkedin" required autocomplete="linkedin"
                                        autofocus value="<?php echo (!empty($Adminusers->linkedin) ? $Adminusers->linkedin : 'Please Enter ' .  'linkedin '  ); ?>">
                                    <label for="floatinglinkedin">linkedin </label>
                                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatinginstagram"
                                        placeholder="Instagram" name="instagram" required autocomplete="instagram"
                                        autofocus value="<?php echo (!empty($Adminusers->instagram) ? $Adminusers->instagram : 'Please Enter ' .  'Instagram'  ); ?>">
                                    <label for="floatinginstagram">Instagram</label>
                                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingtwitter" placeholder="X"
                                        name="twitter" required autocomplete="twitter" autofocus
                                        value="<?php echo (!empty($Adminusers->twitter) ? $Adminusers->twitter : 'Please Enter ' .  'X'  ); ?>">
                                    <label for="floatingtwitter">X</label>
                                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingfacebook"
                                        placeholder="Facebook" name="facebook" required autocomplete="facebook"
                                        autofocus value="<?php echo (!empty($Adminusers->facebook) ? $Adminusers->facebook : 'Please Enter ' .  'Facebook'  ); ?>">
                                    <label for="floatingtfacebook">Facebook</label>
                                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert-color" role="alert">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>



                            <div class="text-center">

                                <button type="submit" class="btn bg-primary_expert btn-style">Submit</button>

                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="Basic_details">
        <div class="modal fade" id="Basic_details" tabindex="-1" aria-labelledby="Basic_etails"
            aria-hidden="true">
            <div class="modal-dialog modal-lg  modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Basic_etails</h1>
                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close"><i
                                class="bi bi-x"></i></button>
                    </div>
                    <div class="modal-body">
                        <form
                            action="<?php echo e(route('admin.registration.tech.profilebasic_details', ['id' => encrypt($Adminusers->id)])); ?>"
                            class="row g-3" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-6 ">
                                <div class="form-floating text-center ">

                                    <?php if($Adminusers->avatar): ?>
                                        <img src="<?php echo e(asset('storage/images/images/' . $Adminusers->avatar)); ?>"
                                            alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                    <?php else: ?>
                                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp"
                                            alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                    <?php endif; ?>



                                </div>


                                <div class="row mt-2">
                                    <div class="col-sm-4 d-flex text-center">
                                        <label for="inputNumber" class="col-form-label">Change Image</label>
                                    </div>

                                    <div class="col-sm-8">
                                        <input type="file" name="image" id="inputImage"
                                            class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                            </div>
                            <div class="col-md-6">
                                <div class="row  g-3 mt-0.9">
                                    <div class="col-md-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" id="floatingfirstName"
                                                placeholder="First Name" name="First_Name" required
                                                autocomplete="First_Name" autofocus value="<?php echo (!empty($Adminusers->firstname) ? $Adminusers->firstname : 'Please Enter ' .  'First Name'  ); ?>">
                                            <label for="floatingfirstName">First Name</label>
                                            <?php $__errorArgs = ['First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert-color" role="alert">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" id="floatingLastName"
                                                placeholder="Last Name" name="Last_Name" required
                                                autocomplete="Last_Name" autofocus value="<?php echo (!empty($Adminusers->lastname) ? $Adminusers->lastname : 'Please Enter ' .  'Last Name'  ); ?>">
                                            <label for="floatingLastName">Last Name</label>
                                            <?php $__errorArgs = ['Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert-color" role="alert">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-floating">
                                            <input type="email" class="form-control" id="floatingEmail"
                                                name="Email" placeholder="Email" required autocomplete="Email"
                                                autofocus value="<?php echo (!empty($Adminusers->users->email) ? $Adminusers->users->email : 'Please Enter ' .  'Email'  ); ?>">
                                            <label for="floatingEmail">Email</label>
                                            <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert-color" role="alert">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>


                                </div>



                            </div>


                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="floatingPhone"
                                            name="Phone_number" placeholder="Phone Number" required
                                            autocomplete="Phone_number" autofocus value="<?php echo (!empty($Adminusers->phonenumber) ? $Adminusers->phonenumber : 'Please Enter ' .  'Phone'  ); ?>">
                                        <label for="floatingPhone">Phone Number</label>
                                        <?php $__errorArgs = ['Phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="floatingAddress"
                                            name="Address" placeholder="Address" required autocomplete="Address"
                                            autofocus value="<?php echo (!empty($Adminusers->Address) ? $Adminusers->Address : 'Please Enter ' .  'Address'  ); ?>">
                                        <label for="floatingAddress">Address</label>
                                        <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="floatingPosition"
                                            name="Postion" placeholder="Position" required autocomplete="Position"
                                            autofocus value="<?php echo (!empty($Adminusers->Position) ? $Adminusers->Position : 'Please Enter ' .  'Position'  ); ?>">
                                        <label for="floatingPosition">Position</label>
                                        <?php $__errorArgs = ['Position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatinggender" name="Gender" required>
                                            <option value="<?php echo (!empty($Adminusers->Gender) ? $Adminusers->Gender : 'Please Enter ' .  'Gender'  ); ?>" <?php if($Adminusers->Gender == ''): ?>
                                                selected
                                                <?php endif; ?>><?php echo (!empty($Adminusers->Gender) ? $Adminusers->Gender : 'Please Enter ' .  'Gender'  ); ?></option>
                                            <option value="male" <?php if($Adminusers->Gender == 'male'): ?> selected <?php endif; ?>>
                                                Male</option>
                                            <option value="female" <?php if($Adminusers->Gender == 'female'): ?> selected <?php endif; ?>>
                                                Female</option>
                                        </select>
                                        <label for="floatingPosition">Gender</label>
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>



                            <div class="text-center">

                                <button type="submit" class="btn bg-primary_expert btn-style">Submit</button>

                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>




</section>

<?php if($errors->any()): ?>
    <?php $__env->startSection('script'); ?>
        <script>
            $(document).ready(function() {
                $('#Basic_details').modal('show');
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/admin/profile_view/tech_view.blade.php ENDPATH**/ ?>