<?php $__env->startSection('contents'); ?>
    <style>
        .start_date {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .bluck_add {}
    </style>
    <style>
        #assign_to select.form-select option.slected {
            background-color: #ff0000;
            /* Change this to your desired color */
            color: #ffffff;
            /* Change this to your desired text color */
        }

        #assign_to .ui-widget.ui-widget-content {
            border: 1px solid #c5c5c5;
            border-radius: 5px;
            padding: 5px !important;
        }

        #assign_to ul#ui-id-2 {
            position: relative;
            width: 300px;
            top: -275.531px;
            left: 40px;
        }
    </style>

    <section class="pagetitle_sec">
        <div id="pagetitle" class="pagetitle">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-12  align-items-center ">
                    <h1>Job List</h1>
                    <nav>
                        <ol class="breadcrumb ">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('tech.dashboard.index')); ?>">Home</a></li>

                            <?php if(!empty($search_page)): ?>
                                <li class="breadcrumb-item active"><a href="<?php echo e(route('tech.joballocation.job_list')); ?>">Job
                                        List</a></li>
                                <li class="breadcrumb-item active">Job Serach Result</li>
                            <?php else: ?>
                                <li class="breadcrumb-item active">Job List</li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                </div>

            </div>

        </div>
    </section>



    

    <?php echo $__env->make('components.task_status_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="section pt-3" id="section_Search">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body ">
                        <div class="row gy-3 mt-3">

                            <form action="<?php echo e(route('tech.joballocation.search')); ?>" class="row g-3" method="GET">

                                <div class="col-xxl-3 col-md-6 ">
                                    <div class="row">
                                        <div class="start_date">
                                            <div class="col-sm-4 mt-2">
                                                <label for="inputDate" class="form-label">Start Date :</label>
                                            </div>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" name="Start_date"
                                                    autocomplete="Start_date"
                                                    value="<?php echo e(!empty($search_page) ? $search_page['start_date'] : ''); ?>">
                                            </div>

                                        </div>
                                        <?php $__errorArgs = ['Start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                </div>
                                <div class="col-xxl-3 col-md-6">
                                    <div class="row">
                                        <div class="start_date">
                                            <div class="col-sm-4  mt-2">
                                                <label for="inputDate" class="form-label">End Date :</label>
                                            </div>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" name="End_date"
                                                    autocomplete="End_date"
                                                    value="<?php echo e(!empty($search_page) ? $search_page['end_date'] : ''); ?>">
                                            </div>

                                        </div>
                                        <?php $__errorArgs = ['End_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert-color" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-xxl-3 col-md-6 text-center">
                                    <div class="row">

                                        <div class="col-sm-12">
                                            <select class="form-select" aria-label="Default select example"
                                                name="Task_value">
                                                <option value="" selected>Please Choose Task</option>

                                                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?> "
                                                        <?php echo e(!empty($search_page) && $search_page['Task_value'] == $item->id ? 'selected' : ''); ?>>
                                                        <span class="service_option_size">
                                                            <?php echo e($item->task_name); ?> </span>
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-xxl-3 col-md-6 text-center ">
                                    <div class="search">
                                        <div class="form-floating mb-3 ">
                                            <button type="submit" class="btn bg-primary_expert"
                                                style="height: 100%; width:50%">search</button>
                                        </div>
                                    </div>

                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="section pt-3" id="section_admin">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">

                        <div class="card_head">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="col-12">
                                    <h5 class="card-title">Job List</h5>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php $__currentLoopData = $prdt_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $groupedItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bluck_add mb-5 mt-2">
                                <h6 class="task_name mb-2 mt-2">Task : <?php echo e($productId); ?></h6>
                                <!-- Table with stripped rows -->
                                <div class="table-responsive">
                                    <table id="admin_table" class="table datatable table-striped">
                                        <thead>
                                            <tr>
                                                <th>sl.no</th>
                                                <th> Product Code</th>
                                                <th>Office Name</th>
                                                <th>Loaction</th>
                                                <th>Service</th>

                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prdt_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($prdt_task->product_add->product_code); ?></td>
                                                    <td><?php echo e($prdt_task->product_add->client_pdt->office); ?></td>
                                                    <td><?php echo e($prdt_task->product_add->client_pdt->location); ?></td>
                                                    <td><?php echo e($prdt_task->type_service->service_name); ?></td>
                                                    <td>
                                                        <div class="action_icon ">
                                                            <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                                data-bs-title="View"
                                                                href="<?php echo e(route('tech.joballocation.job_list_view', ['id' => encrypt($prdt_task->product_id)])); ?>">

                                                                <button type="button" class="btn">
                                                                    <i class="bi bi-eye"></i>
                                                                </button>
                                                            </a>

                                                            <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                                data-bs-title="Start Work"
                                                                href="<?php echo e(route('tech.joballocation.jobinstall', ['id' => encrypt($prdt_task->id)])); ?>">
                                                                <button type="button" class="btn">


                                                                    <i class="bi bi-lightning"></i>
                                                                </button>
                                                            </a>
                                                            <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                                data-bs-title="Add My Job">
                                                                <button type="button" class="btn"
                                                                    data-bs-toggle="modal" data-bs-target="#taken_by"
                                                                    data-bs-whatever=<?php echo e($prdt_task->id); ?>>
                                                                    <i class="bi bi-person-fill-add"></i>
                                                                </button>
                                                            </a>

                                                            <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                                data-bs-title="Assign to Job">
                                                                <button type="button" class="btn"
                                                                    data-bs-toggle="modal" data-bs-target="#assign_to"
                                                                    data-bs-whatever=<?php echo e($prdt_task->id); ?>>
                                                                    <i class="bi bi-person-fill-up"></i>
                                                                </button>
                                                            </a>


                                                        </div>

                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="modal fade" id="taken_by" tabindex="-1" aria-labelledby="taken_byLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add My Job </h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Client Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Office Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Office_Name'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Location Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Location_Name'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Email</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Email'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Phone Number</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Phone_Number'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Product Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Code</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Code">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Brand Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Brand_Name">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Model</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Model">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Name">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                        </div>

                    </div>
                    <form action="<?php echo e(route('tech.joballocation.job_taken')); ?>" method="GET">
                        <div class="mb-3">

                            <input type="hidden" class="form-control" name="pdt_id_name" id="pdt_id_name">
                        </div>
                        <div class="mb-3">

                            <input type="hidden" class="form-control" id="user_id" name="user_id"
                                value="<?php echo e(Auth::user()->id); ?>">
                        </div>
                        <div class="modal-footer d-flex " style="justify-content: space-around;">
                            <button type="submit" class="btn bg-primary_expert ">Confirm Job</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>
    <section id='assign'>
        <div class="modal fade" id="assign_to" tabindex="-1" aria-labelledby="assign_to" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add My Job </h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body mb-5">

                        <div class="row">
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Client Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Office Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Office_Name_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Location Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Location_Name_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Email</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Email_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Phone Number</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id='Phone_Number_assign'>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                            <div class="col-12">

                                <div id="job_deatail_v1" class="">
                                    <div class="head-profie">
                                        <h5 class="card-title">Product Details</h5>

                                    </div>
                                    <div class="row gy-3 gx-1">

                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Code</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Code_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Brand Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Brand_Name_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6  custom-border">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Model</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Model_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 custom-border ">
                                            <div class="under_line">
                                                <div class="row ">
                                                    <div class="col-6 ">
                                                        <p class="mb-0">Product Name</p>
                                                    </div>
                                                    <div class="col-6">
                                                        <p class="text-muted job_detatil_v3" id="Product_Name_assign">
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>


                                </div>

                            </div>
                        </div>
                        <form action="<?php echo e(route('tech.joballocation.job_assign')); ?>" method="GET">
                            <div id="assign_to" class="row">
                                <div class="mb-3">

                                    <input type="hidden" class="form-control" name="pdt_id_name_assign"
                                        id="pdt_id_name_assign">
                                </div>
                                <div class="mb-3">

                                    <input type="hidden" class="form-control" id="user_id" name="user_id"
                                        value="<?php echo e(Auth::user()->id); ?>">
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select" id="Technician_name_assign"
                                            name="Technician_name_assign" required>
                                            <option value="">please choose Technician Name

                                            </option>
                                            <?php $__currentLoopData = $tech; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($technician->user_id); ?>">
                                                    <?php echo e($technician->firstname); ?> <?php echo e($technician->lastname); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <label for="floatingPosition">Technician Name</label>


                                    </div>
                                </div>
                                <div class="col-md-6 "
                                    style="
                                display: flex;
                                align-content: center;
                                justify-content: space-around;
                            ">
                                    <div class="Confirm_assign d-flex "
                                        style="justify-content: space-around; align-items:center">
                                        <button type="submit" class="btn bg-primary_expert ">Confirm To Assign
                                            Job</button>
                                    </div>
                                </div>



                            </div>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
            $(document).ready(function() {
                $("#Technician_name_assign").autocomplete({
                    source: function(request, response) {
                        $.ajax({
                            url: '/tech/joballocation/Technician_name',
                            data: {
                                term: request.term
                            },
                            dataType: "json",
                            success: function(data) {
                                console.log(data);
                                var resp = $.map(data, function(obj) {
                                    return {
                                        id: obj.id,
                                        name: obj.firstname + ' ' + obj.lastname,
                                        user_id: obj.user_id,
                                    };
                                });

                                console.log(resp);

                                if (resp.length === 0) {
                                    resp.push({
                                        label: "No entries found",
                                        value: null // You can set this to an appropriate value
                                    });
                                }

                                response(resp);
                            },
                            error: function(xhr, status, error) {
                                console.error("AJAX Request Error:", status, error);
                            }
                        });
                    },
                    minLength: 2,
                    select: function(event, ui) {
                        // Update the input boxes with the selected technician's name and ID
                        $(this).val(ui.item.name);
                        $(this).siblings(".user-id").val(ui.item.user_id);
                        return false; // Assuming you want to set this value as well
                        return false; // Prevent the default behavior of setting the value in the input box
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tech.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/tech/joballocation/joblist.blade.php ENDPATH**/ ?>