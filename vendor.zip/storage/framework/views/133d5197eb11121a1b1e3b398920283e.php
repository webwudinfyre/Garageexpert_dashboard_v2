
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($mailData['title']); ?></title>
    <style>
        /* Styles for email layout */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .card {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .card-title {
            font-size: 18px;
            margin-bottom: 10px;
            text-align: center;
        }

        .card-content {
            font-size: 14px;
            color: #666666;
            text-align: center;
        }

        .download-status {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }

        .grid-cat {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px; /* Increased gap for better spacing */
        }

        .grid-item {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
        }

        .table-container {
            overflow-x: auto; /* Enable horizontal scroll if table is wider */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table td, table th {
            padding: 10px;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: left;
        }

        .under_line {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .job_detail_v3 {
            font-weight: bold;
        }
        .btn {
        display: inline-block;
        padding: 4px 4px;
        font-size: 14px;
        font-weight: bold;
        text-decoration: none;
        color: #ffffff;
        background-color: #ff530a; /* Primary color, change as needed */
        border: none;
        border-radius: 4px;
        cursor: pointer;

        transition: background-color 0.3s ease;
    }

    .btn:hover {
        background-color: #ff530a; /* Darker shade of primary color on hover */
    }

    /* Bootstrap Icon Styling */
    .bi {
        vertical-align: text-bottom; /* Align icon vertically with text */
        margin-right: 8px; /* Add space between icon and text */
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="<?php echo e($message->embed(public_path('admin/assets/img/Asset_6@4x.png'))); ?>" alt="Logo" style="max-width: 300px">
        </div>

        <div class="card">
            <h2 class="card-title">Product Details</h2>
            <div class="grid-cat">
                <div class="grid-item">
                    <div class="table-container">
                        <table>
                            <tr>
                                <th>Attribute</th>
                                <th>Value</th>
                            </tr>
                            <tr>
                                <td><strong>Product Code</strong></td>
                                <td><?php echo e($mailData['data']->product_code); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Serial Number</strong></td>
                                <td><?php echo e($mailData['data']->serial_number ?: 'Not available'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Brand Name</strong></td>
                                <td><?php echo e($mailData['data']->equip_pdt->Brand); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Model</strong></td>
                                <td><?php echo e($mailData['data']->equip_pdt->Model); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Product Name</strong></td>
                                <td><?php echo e($mailData['data']->equip_pdt->Item_name); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Warranty</strong></td>
                                <td><?php echo e($mailData['data']->warranty->warranty_type === '1' ? 'Yes' : 'No'); ?></td>
                            </tr>
                            <?php if($mailData['data']->warranty->warranty_type === '1'): ?>
                                <tr>
                                    <td><strong>Warranty Current Status</strong></td>
                                    <?php
                                        $endDate = \Carbon\Carbon::parse($mailData['data']->warranty->end_date);
                                        $currentDate = \Carbon\Carbon::now();
                                        $isWarrantyValid = $endDate->gte($currentDate);
                                    ?>
                                    <td><?php echo e($isWarrantyValid ? 'Active' : 'Expired'); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Warranty Start Date</strong></td>
                                    <td><?php echo e($mailData['data']->warranty->Start_date); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Warranty End Date</strong></td>
                                    <td><?php echo e($mailData['data']->warranty->end_date); ?></td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <div class="grid-item">
                    <p class="card-content">

                        <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Download"
                           href="<?php echo e(route('mail.job_pdf_dowmload_mail', ['id' => encrypt( $mailData['data']->product_id)])); ?>"
                           onclick="showModal()">
                            <button type="button" class="btn">
                                <i class="bi bi-download"> Click to download full details</i>
                            </button>
                        </a>
                    </p>
                    <p class="card-content">

                    </p>
                </div>
            </div>

        </div>

    </div>
</body>

</html>

<?php /**PATH C:\laragon\www\Garageexpert_dashboard_v2\resources\views/emails/demoMail.blade.php ENDPATH**/ ?>